package org.example;

import java.util.EventObject;

public class DataSheetChangeEvent extends EventObject {
    public DataSheetChangeEvent(Object source) {
        super(source);
    }
}
