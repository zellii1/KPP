package v1;

import java.io.Serializable;

public class Book implements Serializable {
    private String title;
    private Author[] authors;
    private int year;
    private int edition;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Author[] getAuthors() {
        return authors;
    }

    public void setAuthors(Author[] authors) {
        this.authors = authors;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getEdition() {
        return edition;
    }

    public void setEdition(int edition) {
        this.edition = edition;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Author author : authors) {
            sb.append(author);
        }

        return "Book [title=" + title + ", author=" + sb + ", edition=" + edition + ", year=" + year + "]";
    }
}
