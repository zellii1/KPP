package v1;

import java.io.Serializable;
import java.util.ArrayList;

public class BookReader extends Human implements Serializable {
    private Library library;
    private ArrayList<Book> books;
    private final int id;

    public BookReader(String fullName, int id) {
        super(fullName);
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setLibrary(Library library) {
        this.library = library;
    }

    public void borrowBook(String bookTitle) {
        Book book = library.findBook(bookTitle);
        if (book != null) {
            library.lendBook(book);
            books.add(book);
            System.out.println("You have just borrowed " + book.getTitle());
        } else {
            System.out.println(bookTitle + " is not available.");
        }
    }

    @Override
    public String toString() {
        return "BookReader [name=" + this.getFullName() + ", id=" + id + "]";
    }
}
