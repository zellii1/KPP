package v1;

import java.io.Serializable;

public class Author extends Human implements Serializable {
    public Author(String fullName) {
        super(fullName);
    }

    @Override
    public String toString() {
        return "Author [name=" + this.getFullName() + "]";
    }
}
