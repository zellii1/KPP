package v3;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;

public class BookReader extends Human implements Externalizable {
    private Library library;
    private ArrayList<Book> books;
    private int id;

    public BookReader() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public void setLibrary(Library library) {
        this.library = library;
    }

    public void borrowBook(String bookTitle) {
        Book book = library.findBook(bookTitle);
        if (book != null) {
            library.lendBook(book);
            books.add(book);
            System.out.println("You have just borrowed " + book.getTitle());
        } else {
            System.out.println(bookTitle + " is not available.");
        }
    }

    @Override
    public String toString() {
        return "BookReader [name=" + this.getFullName() + ", id=" + id + "]";
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeInt(id);
        out.writeObject(library);
        out.writeObject(books);
        out.writeObject(getFullName());
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        id = in.readInt();
        library = (Library) in.readObject();
        books = (ArrayList<Book>) in.readObject();
        setFullName((String) in.readObject());
    }
}
