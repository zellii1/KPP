package v3;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.HashMap;
import java.util.Map;

public class BookStore implements Externalizable {
    private String name;
    private Map<Book, Integer> books;

    public BookStore(String name) {
        this.name = name;
        this.books = new HashMap<>();
    }

    public BookStore() {
    }

    public String getName() {
        return name;
    }

    public Map<Book, Integer> getBooks() {
        return books;
    }

    public void addBook(Book book, int quantity) {
        if (books.containsKey(book)) {
            int currentQuantity = books.get(book);
            books.put(book, currentQuantity + quantity);
        } else {
            books.put(book, quantity);
        }
    }

    public void removeBook(Book book, int quantity) {
        if (books.containsKey(book)) {
            int currentQuantity = books.get(book);
            if (currentQuantity <= quantity) {
                books.remove(book);
            } else {
                books.put(book, currentQuantity - quantity);
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder output = new StringBuilder("\n");

        for (Map.Entry<Book, Integer> book : books.entrySet()) {
            output.append(book.getKey()).append("\n");
        }

        return output.toString();
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(name);
        out.writeObject(books);
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        name = (String) in.readObject();
        books = (Map<Book, Integer>) in.readObject();
    }
}
