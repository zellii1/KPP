package v3;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;
import java.util.Map;

public class Library implements Externalizable {
    private String name;
    private ArrayList<BookStore> bookStores = new ArrayList<>();
    private ArrayList<BookReader> readers = new ArrayList<>();

    public Library() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addReader(BookReader reader) {
        reader.setLibrary(this);
        readers.add(reader);
    }

    public void removeReader(BookReader reader) {
        readers.remove(reader);
    }

    public ArrayList<BookReader> getReaders() {
        return readers;
    }

    public void addBookStore(BookStore bookStore) {
        bookStores.add(bookStore);
    }

    public void removeBookStore(BookStore bookStore) {
        bookStores.remove(bookStore);
    }

    public ArrayList<BookStore> getBookStores() {
        return bookStores;
    }

    public Book findBook(String name) {
        for (BookStore bookStore : bookStores) {
            for (Map.Entry<Book, Integer> entry : bookStore.getBooks().entrySet()) {
                Book book = entry.getKey();
                if (book.getTitle().toLowerCase().contains(name.toLowerCase()) && entry.getValue() > 0) {
                    return book;
                }
            }
        }
        return null;
    }

    public boolean lendBook(Book book) {
        for (BookStore bookStore : bookStores) {
            if (bookStore.getBooks().containsKey(book) && bookStore.getBooks().get(book) > 0) {
                bookStore.removeBook(book, 1);
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        int totalBooks = 0;

        for (BookStore bookStore : bookStores) {
            totalBooks += bookStore.getBooks().size();
        }

        return "LibraryЗ [name=" + name + ", bookstores=" + bookStores.size()
                + ", readers=" + readers.size() + ", total books=" + totalBooks + "]";
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(name);
        out.writeObject(bookStores);
        out.writeObject(readers);
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        name = (String) in.readObject();
        bookStores = (ArrayList<BookStore>) in.readObject();
        readers = (ArrayList<BookReader>) in.readObject();
    }
}