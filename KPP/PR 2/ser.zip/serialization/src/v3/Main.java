package v3;

import java.io.*;

public class Main {
    public static void main(String[] args) {
        Author author1 = new Author();
        author1.setFullName("J.K. Rowling");
        Author author2 = new Author();
        author2.setFullName("Stephen King");
        Book book1 = new Book();
        book1.setTitle("Harry Potter and the Philosopher's Stone");
        book1.setAuthors(new Author[]{author1});
        book1.setYear(1997);
        book1.setEdition(1);
        Book book2 = new Book();
        book2.setTitle("The Shining");
        book2.setAuthors(new Author[]{author2});
        book2.setYear(1977);
        book2.setEdition(1);
        BookStore store = new BookStore("Interesting");
        store.addBook(book1, 10);
        store.addBook(book2, 5);
        Library library = new Library();
        library.setName("Library 3");
        BookReader reader1 = new BookReader();
        reader1.setId(1);
        reader1.setFullName("Someone Someonovich");
        BookReader reader2 = new BookReader();
        reader2.setId(2);
        reader2.setFullName("Anyone Anyonovich");
        library.addReader(reader1);
        library.addReader(reader2);
        library.addBookStore(store);

        try {
            FileOutputStream fileOut = new FileOutputStream("library.ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(library);
            out.close();
            fileOut.close();
            System.out.println("Serialized data saved in library.ser");
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            FileInputStream fileIn = new FileInputStream("library.ser");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            Library libraryDeserialized = (Library) in.readObject();
            System.out.println("Deserialized data loaded from library.ser");
            System.out.println(libraryDeserialized);
            System.out.println(libraryDeserialized.getBookStores());
            in.close();
            fileIn.close();
        } catch (IOException i) {
            i.printStackTrace();
        } catch (ClassNotFoundException c) {
            System.out.println("Class not found");
            c.printStackTrace();
        }
    }
}