package v2;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class BookReader extends Human implements Serializable {
    private Library library;
    private transient ArrayList<Book> books = new ArrayList<>();
    private final int id;

    public BookReader(String fullName, int id) {
        super(fullName);
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setLibrary(Library library) {
        this.library = library;
    }

    public void borrowBook(String bookTitle) {
        Book book = library.findBook(bookTitle);
        if (book != null) {
            library.lendBook(book);
            books.add(book);
            System.out.println("You have just borrowed " + book.getTitle());
        } else {
            System.out.println(bookTitle + " is not available.");
        }
    }

    @Override
    public String toString() {
        return "BookReader [name=" + this.getFullName() + "]";
    }

    private void writeObject(ObjectOutputStream out) throws IOException {
        out.defaultWriteObject();
        out.writeInt(books.size());
        for (Book book : books) {
            out.writeObject(book);
        }
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        int numBooks = in.readInt();
        books = new ArrayList<>();
        for (int i = 0; i < numBooks; i++) {
            Book book = (Book) in.readObject();
            books.add(book);
        }
    }
}
