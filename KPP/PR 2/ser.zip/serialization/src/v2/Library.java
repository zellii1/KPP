package v2;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;

public class Library implements Serializable {
    private final String name;
    private transient ArrayList<BookStore> bookStores;
    private transient ArrayList<BookReader> readers;

    public Library(String name) {
        this.name = name;
        this.bookStores = new ArrayList<BookStore>();
        this.readers = new ArrayList<BookReader>();
    }

    public String getName() {
        return name;
    }

    public void addReader(BookReader reader) {
        reader.setLibrary(this);
        readers.add(reader);
    }

    public void removeReader(BookReader reader) {
        readers.remove(reader);
    }

    public ArrayList<BookReader> getReaders() {
        return readers;
    }

    public void addBookStore(BookStore bookStore) {
        bookStores.add(bookStore);
    }

    public void removeBookStore(BookStore bookStore) {
        bookStores.remove(bookStore);
    }

    public ArrayList<BookStore> getBookStores() {
        return bookStores;
    }

    public Book findBook(String name) {
        for (BookStore bookStore : bookStores) {
            for (Map.Entry<Book, Integer> entry : bookStore.getBooks().entrySet()) {
                Book book = entry.getKey();
                if (book.getTitle().toLowerCase().contains(name.toLowerCase()) && entry.getValue() > 0) {
                    return book;
                }
            }
        }
        return null;
    }

    public boolean lendBook(Book book) {
        for (BookStore bookStore : bookStores) {
            if (bookStore.getBooks().containsKey(book) && bookStore.getBooks().get(book) > 0) {
                bookStore.removeBook(book, 1);
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        int totalBooks = 0;

        for (BookStore bookStore : bookStores) {
            totalBooks += bookStore.getBooks().size();
        }

        return "Library [name=" + name + ", bookstores=" + bookStores.size()
                + ", readers=" + readers.size() + ", total books=" + totalBooks + "]";
    }

    private void writeObject(ObjectOutputStream out) throws IOException {
        out.defaultWriteObject();

        out.writeInt(bookStores.size());
        for (BookStore bookStore : bookStores) {
            out.writeObject(bookStore);
        }

        out.writeInt(readers.size());
        for (BookReader reader : readers) {
            out.writeObject(reader);
        }
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();

        int numBookStores = in.readInt();
        bookStores = new ArrayList<BookStore>();
        for (int i = 0; i < numBookStores; i++) {
            BookStore bookStore = (BookStore) in.readObject();
            bookStores.add(bookStore);
        }

        int numReaders = in.readInt();
        readers = new ArrayList<BookReader>();
        for (int i = 0; i < numReaders; i++) {
            BookReader reader = (BookReader) in.readObject();
            readers.add(reader);
        }
    }
}