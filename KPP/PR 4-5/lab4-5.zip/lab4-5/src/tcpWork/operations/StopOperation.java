package tcpWork.operations;

import tcpWork.operations.CardOperation;

public class StopOperation extends CardOperation {
}