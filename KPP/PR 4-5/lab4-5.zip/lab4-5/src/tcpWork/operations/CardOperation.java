package tcpWork.operations;

public abstract class CardOperation implements java.io.Serializable {
}